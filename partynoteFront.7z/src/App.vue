<template>
  <v-app>
    <v-app-bar
      app
      color="secondary"
      dark
      flat
      clipped-right
    >
    <!-- 이거 보드 아이콘이면 좋겠다. -->

    <v-icon large class="mr-2" :color="user.color">{{user.icon}}</v-icon>
    <small class="headline" @click="goMain" style="cursor:pointer;" >PartyNote</small>

    <v-spacer></v-spacer>

    <Login v-if="!islogin"
    v-on:login="fetchLogin"
    ></Login>

    <transition name="fade">
    <v-btn text small :fab="!btnhover" v-if="islogin"
    @mouseenter="btnhover=true" @mouseleave="btnhover=false"
    :color="user.color"
    @click="reColor"
    >
      <v-icon>mdi-recycle</v-icon>
      <span v-show="btnhover" class="ml-2">ReColor?</span>
    </v-btn>
    </transition>
    <v-menu offset-y class="mr-3" v-if="islogin">
      <template v-slot:activator="{ on }">
        <v-btn text v-on="on">
        <v-avatar size="37" class="mr-3" :color="user.color">
          <v-icon>{{user.icon}}</v-icon>
        </v-avatar>
        <span class="">{{user.name}}</span>
        </v-btn>
      </template>
      <v-list dense dark class="secondary">
        <v-list-item
        to="/profile"
        >
          <v-icon left small>mdi-cupcake</v-icon>
          <v-list-item-title>프로필</v-list-item-title>
        </v-list-item>

        <v-list-item
       @click="logOut"
        >
        <v-icon left small>mdi-bomb</v-icon>
          <v-list-item-title>로그아웃</v-list-item-title>
        </v-list-item>

        <v-list-item
        to="/friendList"
        >
          <v-icon left small>mdi-muffin</v-icon>
          <v-list-item-title>친구</v-list-item-title>
        </v-list-item>

        <v-list-item
        to="/noteIndex"
        >
          <v-icon left small>mdi-book</v-icon>
          <v-list-item-title>다이어리 보기</v-list-item-title>
        </v-list-item>
        <v-list-item
        @click=""
        >
          <v-icon left small>mdi-email</v-icon>
          <v-list-item-title>쪽지 보내기</v-list-item-title>
        </v-list-item>
      </v-list>
    </v-menu>
    </v-app-bar>
       <v-content fill-height :class="user.color" style="max-width:100%;">
         <transition name="fade" mode="out-in">
         <router-view v-on:drawerControll="RightDrawer=!RightDrawer"></router-view>
        <!-- <BeforeLogin></BeforeLogin> -->
        </transition>
       </v-content>
  </v-app>
</template>

<script>
import Login from './components/login.vue'

export default {
  name: 'App',
  components: {
    Login

  },
  created () {
    // 유저 정보 불러오기. axios를 이용하여 다이어리와 포스트를 불러와 백엔드와 통신.
    this.user.color = this.randomColor()
    sessionStorage.setItem('userColor', this.user.color)
    this.user.icon = this.randomAvatar()
  },
  data () {
    return {
      user: {
        color: 'blue',
        icon: 'mdi-cupcake',
        name: 'Kim'
      },
      cards: [],
      islogin: false,
      btnhover: false,
      EditBtnsOn: false,
      DeleteMode: false,
      NewDiaryBtn: false,
      OpenModal: false,
      RightDrawer: false,
      ModalShow: {
        title: '',
        date: '',
        contents: '',
        button: ''
      },
      ModalCase: 'create',
      EditedTitle: 'New Card'
    }
  },
  methods: {
    fetchLogin () {
      this.user.name = sessionStorage.getItem('loginUser')
      this.islogin = true
    },
    logOut () {
      console.log('로그아웃')
      sessionStorage.clear()
      this.user.name = ''
      this.islogin = false
      alert('로그아웃 되었습니다.')
      this.$router.push('/')
    },
    // 탑바 계정 랜덤 결정기
    randomAvatar () {
      const str = 'mdi-'
      const icons = [
        'cupcake',
        'cup-water',
        'cat',
        'dog',
        'cow',
        'fruit-watermelon',
        'fruit-pineapple',
        'fishbowl',
        'castle',
        'chef-hat',
        'skull'
      ]
      const randomCase = Math.floor(Math.random() * 11)
      return `${str}${icons[randomCase]}`
    },
    randomColor () {
      const colors = [
        'red',
        'pink',
        'purple',
        'deep-purple',
        'indigo',
        'blue',
        'light-blue',
        'cyan',
        'teal',
        'green',
        'light-green',
        'lime',
        'yellow',
        'amber',
        'orange',
        'deep-orange'
      ]
      const brighten = ['lighten-3', 'lighten-2', 'lighten-1']
      const colorCase = Math.floor(Math.random() * 16)
      const brightCase = Math.floor(Math.random() * 3)

      return `${colors[colorCase]} ${brighten[brightCase]}`
    },
    reColor () {
      this.user.color = this.randomColor()
    },
    goMain () {
      this.$router.push('/')
    }
  }
}
</script>
<style>
html::-webkit-scrollbar {
  width: 5px;
  height: 8px;
  border: 3px solid #fff;
  display: none !important; /* Chrome, Safari, Opera*/
}
body{
cursor: url('assets/cursor-default.png'), default;
}
/* ::-webkit-scrollbar {
  width: 5px;
  height: 8px;
  border: 3px solid #fff;} */
::-webkit-scrollbar-button:start:decrement, ::-webkit-scrollbar-button:end:increment {
  display: block;
  height: 10px;
  background: grey;
  border-radius: 3px;
  }
::-webkit-scrollbar-track {
  background: #efefef;
  border-radius: 10px;
  border-radius:10px;
  box-shadow: inset 0 0 4px rgba(0,0,0,.2);
  }

::-webkit-scrollbar-thumb {
  height: 50px;
  width: 50px;
  background: rgba(0,0,0,.2);
  border-radius: 8px;
  border-radius: 8px;
  box-shadow: inset 0 0 4px rgba(0,0,0,.1);
  }

.selophan{
  opacity:0.6;
  background-color: black;
  color: white;
}
.fade-enter-active, .fade-leave-active {
  transition: opacity .2s !important;
}
.fade-enter, .fade-leave-to /* .fade-leave-active below version 2.1.8 */ {
  opacity: 0 !important ;
}
.slide-fade-enter-active {
  transition: all .3s ease;
}
.slide-fade-leave-active {
  transition: all .8s cubic-bezier(1.0, 0.5, 0.8, 1.0);
}
.slide-fade-enter, .slide-fade-leave-to
/* .slide-fade-leave-active below version 2.1.8 */ {
  transform: translateX(10px);
  opacity: 0;
}
</style>
