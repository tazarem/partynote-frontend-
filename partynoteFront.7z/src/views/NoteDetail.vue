<template>
   <!-- class="grey lighten-3" -->
      <v-layout fill-height column :class="this.note.color" style="position:static !important;">

    <v-navigation-drawer
      v-model="RightDrawer"
      app
      clipped
      right
    >
      <v-list dense class="py-0" height="100%">
        <v-list-item class="black" style="opacity:0.6;">
          <!-- <v-list-item-action>
            <v-icon>mdi-cupcake</v-icon>
          </v-list-item-action> -->
          <v-list-item-content>
            <v-list-item-title class="d-flex flex-center justify-space-around align-center">
              <v-icon
              dark
              @click=""
              >mdi-chevron-left</v-icon>

              <v-chip :color="randomColor()" dark>
                <v-icon small class="mr-2">mdi-eye</v-icon>
                <small>카드로 보기</small>
                </v-chip>
              <v-icon
              dark
              @click=""
              >mdi-chevron-right</v-icon>
              </v-list-item-title>
          </v-list-item-content>
        </v-list-item>

          <scheduler></scheduler>
        <v-divider></v-divider>
          <hotline></hotline>
        <v-divider></v-divider>
          <tagfilter></tagfilter>
        <v-divider></v-divider>
      </v-list>
    </v-navigation-drawer>

          <!-- 보드타이틀 툴바 -->
    <v-layout style="max-height:fit-content;">
      <v-toolbar class="white--text black selophan" dense flat
      >
        <span>{{NoteTitle}}</span>
        <v-spacer></v-spacer>
        <v-btn dark text fab x-small
        ><v-icon>mdi-menu-up</v-icon></v-btn>
      </v-toolbar>
      </v-layout>
<!-- 드로어 툴바 -->
      <v-toolbar color="transparent" flat max-height="fit-content">
      {{NoteDes}}
      <v-spacer></v-spacer>
        <v-btn fab small dark depressed color="black"
        style="opacity:0.57;"
        @click="drawerOpen"
        >
          <v-icon>{{RightDrawer===true?'mdi-chevron-right':'mdi-chevron-left'}}</v-icon>
        </v-btn>

      <!-- </v-btn-toggle> -->

      </v-toolbar>

    <v-layout class="px-3" fill-height>
    <v-layout style="flex-wrap: wrap; min-width:190px; max-width:190px;">
      <!--카드 생성 버튼 -->
      <v-hover
      v-slot:default="{ hover }"
      >
      <v-card class="pa-3 ml-4 mb-2 defaultMode"
      min-width="fit-content"
      max-height="50"
      color="black" dark flat
      v-if="true"
      :elevation="hover? 10:3"
      style="opacity:0.6;"
      @click="openCreateModal"
      >
      <span class="mr-3">새 포스트..</span>
        <v-icon>mdi-plus</v-icon>
      </v-card>
      </v-hover>
      <!-- 카드 생성 버튼 끝 -->
    </v-layout>

    <v-layout class="pl-0"
    style="flex-wrap: wrap !important; align-content: flex-start;
    justify-content: flex-start;">
          <!-- 신규 생성되는 구간 -->
      <template class="card-zone"
      v-for="(card , index) in this.cards"
      >
      <v-hover
      v-slot:default="{ hover }"
      :key="index"
      >
      <v-card
      class="pa-3 mr-3 mb-2 card-posts defaultMode"
      width="225"
      min-height="138"
      height="fit-content"
      :color="card.postColor"
      flat
      absolute
      :elevation="hover? 10:3"
      :id="index"
      :key="index"
      @click="showModal(card)"
      @dragstart="cardDragStart"
      @dragend="cardDragEnd"
      @dragover="allowCardDrop"
      @drop="dropCard"
      :draggable="true"
      >
      <!--
        max-width="300"
      max-height="100" -->
        <!-- 카드 -->
        <template>
        <span
        >{{ card.postTitle }}</span>
        <!-- .substring(0,15) -->
        <!-- <small v-if="card.postTitle.length>15">..</small> -->
        <v-divider></v-divider>
        <div class="d-flex justify-end align-center my-1">
                <span style="font-size:13px;"
                class="font-weight-bold">{{card.postSubtitle}}</span>
                <!-- .substring(0,10) -->
                <v-spacer></v-spacer>
                <small class="overline"></small>
        </div>
        <small class="body-2" v-html="card.postContents">
          <!--  .replace(/>[^>]*>?/gm).substring(0 ,64)-->
        </small>
        </template>
        <!-- 카드 -->

      </v-card>
      </v-hover>
      </template>
      <!-- 신규 생성되는 구간 -->
</v-layout>
              <!-- 모달 다이얼로그 컴포넌트 -->
      <modal
      v-on:newcard="createNewCard"
      v-on:close="closeModal"
      :modalCase="ModalCase"
      :dialog="OpenModal"
      v-if="OpenModal"
      >
        <template v-slot:header>{{ModalShow.title}}</template>
        <template v-slot:recentdate>{{ModalShow.date}}</template>
        <template v-slot:subtitle>{{ModalShow.subtitle}}</template>
        <template v-slot:contents >
          <div v-html="ModalShow.contents"></div>
        </template>
      </modal>
      <!-- 모달 다이얼로그 컴포넌트 -->

    </v-layout>
</v-layout>
</template>

<script>
import Modal from '../components/modal.vue'
import Scheduler from '../components/drawercomp/scheduler'
import Hotline from '../components/drawercomp/hotline'
import Tagfilter from '../components/drawercomp/tagfilter'
import axios from 'axios'
export default {
  components: {
    Modal,
    // BeforeLogin,
    // Login,
    Scheduler,
    Hotline,
    Tagfilter
  },
  created () {
    // 유저 정보 불러오기. axios를 이용하여 다이어리와 포스트를 불러와 백엔드와 통신.
    this.bringPosts()
    this.note.color = sessionStorage.getItem('anColor')
    // this.user.icon = this.randomAvatar()
  },
  data () {
    return {
      note: {
        color: 'blue',
        icon: 'mdi-cupcake'
      },
      cards: [],
      thisNoteCode: this.$route.params.noteCode,
      NoteTitle: sessionStorage.getItem('anTitle'),
      NoteDes: sessionStorage.getItem('anDes'),
      DeleteMode: false,
      NewDiaryBtn: false,
      OpenModal: false,
      RightDrawer: false,
      ModalShow: {
        title: '',
        date: '',
        color: '',
        contents: '',
        button: ''
      },
      ModalCase: 'create',
      EditedTitle: 'New Card'
    }
  },
  methods: {

    drawerOpen () {
      this.RightDrawer = !this.RightDrawer
      this.$emit('drawerControll')
    },
    openCreateModal () {
      this.ModalCase = 'create'
      this.ModalShow = {
        title: '새 카드 만들기',
        date: '',
        contents: ''
      }
      // console.log(this.ModalShow)
      this.OpenModal = true // 오버레이 컴포넌트 만들어야하고
    },
    createNewCard (newCard) {
      this.OpenModal = false
      newCard.postCode = this.thisNoteCode
      newCard.postColor = this.randomColor()
      newCard.date = this.bringDate()
      newCard.postIndex = this.cards.length
      console.log(newCard)
      // 최근 것의 인덱스를 가져와서 +1 을 해서 속성부여한다.
      axios.post('http://localhost:9000/partynote/makePost', newCard).then((req) => {
        this.bringPosts()
      })
      // this.cards.splice(0, 0, newCard) // 최신 포스트가 앞에 들어감
    },
    bringDate () {
      let nowAdays = ''
      const date = new Date()
      const d = {
        yyyy: date.getFullYear(),
        mm: date.getMonth(),
        dd: date.getDay(),
        hh: date.getHours(),
        md: date.getMinutes()
      }
      let amOrPm = ''
      // console.log(d.yyyy)
      const keyss = Object.keys(d)
      // console.log(keyss)
      for (const key in keyss) {
        if (d[keyss[key]] < 10) {
          d[keyss[key]] = '0' + d[keyss[key]]
        }
        if (d[keyss[key]] > 12) {
          amOrPm = '오후'
        } else {
          amOrPm = '오전'
        }
      }
      nowAdays = `${d.yyyy}-${d.mm}-${d.dd} ${amOrPm} ${d.hh}:${d.mm}`
      return nowAdays
    },
    closeModal () {
      // 값 초기화
      this.ModalShow = {
        title: '',
        date: '',
        subtitle: '',
        contents: ''
      }
      this.ModalCase = 'create'
      // 모달 비활성화
      this.OpenModal = false
    },
    showModal (post) {
      // console.log(post)
      this.ModalShow = {
        title: post.postTitle,
        date: post.date,
        color: post.postColor,
        subtitle: post.postSubtitle,
        contents: post.postContents
      }
      this.ModalCase = 'show'
      // 모달 활성화
      this.OpenModal = true
    },
    // 드래그앤 드랍 개체의 함수
    cardDragStart (e) {
      const objid = this.deepSet(e.target.id)
      e.dataTransfer.setData('text', objid)
      setTimeout(() => {
        e.target.style.opacity = 0
      }, 0)
    },
    cardDragEnd (e) {
      // axios요청으로 동기화시켜야함
      // axios.연속업데이트 index목록 배열형태
      setTimeout(() => {
        e.target.style.opacity = 1
      }, 0)
      console.log(this.cards)
    },
    deepSet (obj) {
      return JSON.parse(JSON.stringify(obj))
    },
    // 드래그앤 드랍 존
    allowCardDrop (e) {
      console.log('allow card drop.')
      e.preventDefault()
    },
    async dropCard (e) {
      // 포인터 때문에 데이터 유실이 있는데 배열리턴을 받아야할것 같음.
      const zoneIndex = this.deepSet(e.target.id)
      const sortIndex = this.deepSet(e.dataTransfer.getData('text')) // 변환시킬 개체의 순서
      const temp = this.deepSet(this.cards[sortIndex])
      let newCardsArray = this.deepSet(this.cards)
      // set Index
      await newCardsArray.splice(sortIndex, 1, this.cards[zoneIndex])
      await newCardsArray.splice(zoneIndex, 1, temp)

      newCardsArray = await this.indexSetting(newCardsArray, sortIndex, zoneIndex)

      this.cards = newCardsArray
      // 이 두 개체를 가지고 업데이트를 쳐라!
      // axios.post(map 형태로 이루어진 인덱스 배열 넘겨서 업데이트 치기)
    },
    indexSetting (newArray, sort, zone) {
      newArray[sort].postIndex = sort
      newArray[zone].postIndex = zone
      return newArray
    },
    // 탑바 계정 랜덤 결정기
    randomAvatar () {
      const str = 'mdi-'
      const icons = [
        'cupcake',
        'cup-water',
        'cat',
        'dog',
        'cow',
        'fruit-watermelon',
        'fruit-pineapple',
        'fishbowl',
        'castle',
        'chef-hat',
        'skull'
      ]
      const randomCase = Math.floor(Math.random() * 11)
      return `${str}${icons[randomCase]}`
    },
    randomColor () {
      const colors = [
        'red',
        'pink',
        'purple',
        'deep-purple',
        'indigo',
        'blue',
        'light-blue',
        'cyan',
        'teal',
        'green',
        'light-green',
        'lime',
        'yellow',
        'amber',
        'orange',
        'deep-orange'
      ]
      const brighten = ['lighten-3', 'lighten-2', 'lighten-1']
      const colorCase = Math.floor(Math.random() * 16)
      const brightCase = Math.floor(Math.random() * 3)

      return `${colors[colorCase]} ${brighten[brightCase]}`
    },
    bringPosts () {
      axios.post('http://localhost:9000/partynote/bringPost', this.thisNoteCode).then((req) => {
        console.log(req.data)
        this.cards = req.data
      })
    }
  },
  watch: {
  },
  beforeDestroy () {
    // sessionStorage.removeItem('activeNote')
    // sessionStorage.removeItem('anTitle')
    // sessionStorage.removeItem('anDes')
    // sessionStorage.removeItem('anColor')
  }

}
</script>

<style>

</style>
